package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.dao.LibraryDao;
import com.cg.dao.IlibraryDao;
import com.cg.model.Book;
import com.cg.model.Library;

@Controller
public class Controllerlib {
	
    IlibraryDao dao=new LibraryDao();
	
    @RequestMapping("/addBook")
	public void addBook(HttpServletRequest request,HttpServletResponse response) throws IOException 
	{
    	
		String libraryId=request.getParameter("lid");
    	        String libraryName=request.getParameter("lname");

    	        String bookId=request.getParameter("boid");
		String bookName=request.getParameter("boname");
		String author=request.getParameter("auth");
		String publisher=request.getParameter("publi");
		
		String bookId2=request.getParameter("boid2");
		String bookName2=request.getParameter("boname2");
		String author2=request.getParameter("auth2");
		String publisher2=request.getParameter("publi2");
		
		PrintWriter out=response.getWriter();
		out.println("Library Books and their Data:");
		out.println(libraryId);
		out.println(libraryName);out.println("<br><br>");
		
		out.println("Book1 Details are:");
		out.println(bookId);
		out.println(bookName);
		out.println(author);
		out.println(publisher);out.println("<br><br>");

		out.println("Book2 Details are:");
		out.println(bookId2);
		out.println(bookName2);
		out.println(author2);
		out.println(publisher2);
		
		
		Library libra=new Library();
	
		libra.setLibraryId(libraryId);
		libra.setLibraryName(libraryName);
		Book b=new Book();
		b.setBookId(bookId);
		b.setBookName(bookName);
		b.setAuthor(author);
		b.setPublisher(publisher);
		b.setLibrary(libra);
		libra.getBook().add(b);
		
		Book b2=new Book();
		b2.setBookId(bookId2);
		b2.setBookName(bookName2);
		b2.setAuthor(author2);
		b2.setPublisher(publisher2);
		b2.setLibrary(libra);
		libra.getBook().add(b2);
		dao.add(libra);

	}
	
	@RequestMapping("/deleteBook")
	public void deleteBook(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		IlibraryDao dao = new LibraryDao();
		dao.deleteBook(request.getParameter("deleteboid"));
		out.println("BookID "+request.getParameter("deleteboid")+" deleted. ");
	}
	
	
	@RequestMapping("/searchBook")
	public void searchBook(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		Library li = dao.getLibrary(request.getParameter("getid"));
		
		if(li!=null)
		{
			out.println("Library Id:"+li.getLibraryId());
                        out.print("<br>");
			out.println("Library Name:"+li.getLibraryName());
			
		}

		Book boo = dao.getBookbyId(request.getParameter("getboid"));
		
		  if(boo!=null) {
                  out.println("Book Id : "+boo.getBookId());out.print("<br>");
		  out.println("Book Name : "+boo.getBookName());out.print("<br>");
		  out.println("Author : "+boo.getAuthor());out.print("<br>");
		  out.println("Publisher : "+boo.getPublisher());
                  }else {
		        out.println("Enter valid BookId");
                   }

	}
	
	
	@RequestMapping("/updateBook")
	public void updateBook(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");	
		
		String id = request.getParameter("boId");
		String bookame = request.getParameter("boName");
		String auth = request.getParameter("Auth");
		String publi = request.getParameter("Publi");
		
		Book book = dao.getBookbyId(id);

		Book nwbook = dao.updateBookData(id,bookname,auth,publi);
		 	
	  	out.println("...........After Updating Data:..........");
                out.print("<br>");
		out.println("Book Name : " +nwbook.getBookName());out.print("<br>");
		out.println("Book Author : "+nwbook.getAuthor());out.print("<br>");
		out.println("Book Publisher Name : "+nwbook.getPublisher());out.print("<br>");

	}
}
