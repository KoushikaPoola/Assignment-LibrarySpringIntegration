package com.cg.dao;

import com.cg.model.Book;
import com.cg.model.Library;

public interface IlibraryDao {
	
	public void addBook(Library lib);
	public Library getLibrary(String libraryId);
	public Book getBookbyId(String bookId);
	public void deleteBook(String bookId);
        public Book updateBookData(String id, String bookname, String auth, String publi);
	
}
